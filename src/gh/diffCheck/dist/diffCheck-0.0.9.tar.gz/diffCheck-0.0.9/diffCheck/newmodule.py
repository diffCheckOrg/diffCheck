


def test_new_mdoule():
    print("hello from test_new_mdoule")