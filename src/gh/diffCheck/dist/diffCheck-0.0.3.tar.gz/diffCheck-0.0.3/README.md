# DiffCheck Grasshopper Plugin

DiffCheck is a plugin for Rhino/Grasshopper that allows the user to compare a 3D model with its scan. 

More information to come